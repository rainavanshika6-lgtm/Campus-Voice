import json
import os
import uuid
import hmac
import re
from datetime import datetime, timezone
from decimal import Decimal

import boto3
from boto3.dynamodb.conditions import Attr

TABLE_NAME = os.environ.get("FEEDBACK_TABLE", "StudentFeedback")
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "")

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)


def json_safe(value):
    if isinstance(value, Decimal):
        return int(value) if value % 1 == 0 else float(value)
    if isinstance(value, dict):
        return {k: json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    return value


def response(status, payload):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": os.environ.get("ALLOWED_ORIGIN", "*"),
            "Access-Control-Allow-Headers": "content-type,x-admin-token",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
            "Cache-Control": "no-store",
        },
        "body": json.dumps(json_safe(payload)),
    }


def get_method_path(event):
    # Supports API Gateway HTTP API payload v2 and REST API proxy events.
    method = (
        event.get("requestContext", {}).get("http", {}).get("method")
        or event.get("httpMethod")
        or "GET"
    ).upper()
    path = event.get("rawPath") or event.get("path") or "/"
    return method, path.rstrip("/") or "/"


def handler(event, context):
    method, path = get_method_path(event)
    if method == "OPTIONS":
        return response(200, {"ok": True})

    if method == "POST" and path.endswith("/feedback"):
        try:
            body = event.get("body") or "{}"
            if event.get("isBase64Encoded"):
                import base64
                body = base64.b64decode(body).decode("utf-8")
            data = json.loads(body)
        except (ValueError, TypeError):
            return response(400, {"message": "Request body must be valid JSON."})

        student_id = str(data.get("student_id", "")).strip()
        course = str(data.get("course", "")).strip()
        faculty = str(data.get("faculty", "")).strip()
        comments = str(data.get("comments", "")).strip()
        student_name = str(data.get("student_name", "")).strip()
        try:
            rating = int(data.get("rating"))
        except (ValueError, TypeError):
            rating = 0

        if not student_id or not course or not faculty or not comments:
            return response(400, {"message": "Student ID, course, faculty and comments are required."})
        if len(student_id) > 40 or len(course) > 120 or len(faculty) > 100:
            return response(400, {"message": "One or more fields are too long."})
        if len(comments) > 1500 or len(student_name) > 80:
            return response(400, {"message": "One or more fields are too long."})
        if rating not in range(1, 6):
            return response(400, {"message": "Rating must be between 1 and 5."})

        feedback_id = str(uuid.uuid4())
        item = {
            "feedback_id": feedback_id,
            "student_id": student_id,
            "student_name": student_name,
            "course": course,
            "faculty": faculty,
            "rating": rating,
            "comments": comments,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        table.put_item(Item=item, ConditionExpression=Attr("feedback_id").not_exists())
        return response(201, {"message": "Feedback saved.", "feedback_id": feedback_id})

    if method == "GET" and path.endswith("/admin/feedback"):
        headers = {str(k).lower(): str(v) for k, v in (event.get("headers") or {}).items()}
        supplied = headers.get("x-admin-token", "")
        if not ADMIN_TOKEN or not hmac.compare_digest(supplied, ADMIN_TOKEN):
            return response(401, {"message": "Unauthorized. Valid admin token required."})
        # Scan is suitable only for a small classroom demo. Add pagination/indexes for production.
        result = table.scan(Limit=1000)
        items = result.get("Items", [])
        while result.get("LastEvaluatedKey") and len(items) < 5000:
            result = table.scan(ExclusiveStartKey=result["LastEvaluatedKey"], Limit=1000)
            items.extend(result.get("Items", []))
        return response(200, {"feedback": items[:5000], "count": len(items[:5000])})

    return response(404, {"message": "Route not found. Use POST /feedback or GET /admin/feedback."})
