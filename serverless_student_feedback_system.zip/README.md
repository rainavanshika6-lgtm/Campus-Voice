# CampusVoice — Serverless Student Feedback Management System

A beginner-friendly AWS Academy project starter. It contains a responsive student feedback website and a Python AWS Lambda backend for Amazon DynamoDB.

## Architecture

Browser (HTML/CSS/JavaScript) → Amazon API Gateway → AWS Lambda (Python) → Amazon DynamoDB

## Included

- `frontend/index.html`: student feedback form and admin analytics dashboard
- `backend/lambda_function.py`: POST feedback and token-protected admin GET endpoint
- `architecture.txt`: architecture summary

## Before you begin

1. Start AWS Academy Learner Lab and open the AWS Management Console.
2. Check the lab's allowed region, service restrictions and remaining budget.
3. This project is not deployed automatically by downloading the ZIP. You must create the AWS resources below.
4. Do not put AWS access keys or other secrets in the HTML file or commit them to a public repository.

## Deployment guide

### A. Create DynamoDB table

1. Open Amazon DynamoDB → Tables → Create table.
2. Table name: `StudentFeedback`
3. Partition key: `feedback_id`, type `String`.
4. Keep defaults appropriate for your lab and create the table.
5. Keep the table in the same region as your Lambda function.

### B. Create Lambda function

1. Open AWS Lambda → Create function → Author from scratch.
2. Name: `CampusVoiceFeedbackApi`
3. Runtime: Python 3.12 (or another Python runtime offered by your lab).
4. Create the function.
5. In Configuration → Environment variables, add:
   - `FEEDBACK_TABLE` = `StudentFeedback`
   - `ADMIN_TOKEN` = a long random demo token, e.g. create your own 32+ character value
   - `ALLOWED_ORIGIN` = `*` for initial lab testing only; after hosting, replace `*` with your exact website origin if feasible.
6. Replace the starter code in `lambda_function.py` with `backend/lambda_function.py` and click Deploy.
7. In Configuration → Permissions, open the execution role. Add an inline policy granting only `dynamodb:PutItem` and `dynamodb:Scan` on your `StudentFeedback` table ARN. Do not use broad administrator permissions. The table scan is only for a small classroom demo.
8. Test the function after creating the API below. A direct Lambda test event is possible, but DynamoDB permissions and table must exist first.

### C. Create API Gateway

Use an HTTP API if your lab offers it.

1. Open API Gateway → Create API → HTTP API → Build.
2. Add integration: Lambda → `CampusVoiceFeedbackApi`.
3. Create routes:
   - `POST /feedback`
   - `GET /admin/feedback`
4. Attach both routes to the Lambda integration and deploy to a stage (for example `$default`).
5. Configure CORS for your frontend origin. For initial testing you can allow origin `*`, methods `GET`, `POST`, `OPTIONS`, and headers `content-type`, `x-admin-token`. Restrict origin after hosting.
6. Copy the Invoke URL. It usually resembles `https://xxxx.execute-api.region.amazonaws.com`. Do not add `/feedback` to the saved base URL; the website adds route paths itself.

### D. Connect the website

1. Open `frontend/index.html` in a browser or host it using an option permitted by your lab.
2. Click Admin dashboard.
3. Paste the API Gateway base Invoke URL.
4. Enter the same `ADMIN_TOKEN` value you configured in Lambda.
5. Click Load dashboard. The API URL is stored only in the current page session; reload may clear it.
6. To submit feedback, return to Submit feedback. Ensure the API Gateway base URL has been entered first. Submit a test record.
7. Return to Admin dashboard and load it again. Your new record should appear.

### E. Host the frontend

If the lab permits S3 static website hosting, create a bucket with a globally unique name, upload `frontend/index.html`, and enable static website hosting. Follow the lab's restrictions; public bucket access may be blocked by policy. Do not disable security controls just to make public hosting work. If S3 website hosting is restricted, use the HTML locally for demonstration or ask your instructor which approved hosting method is available.

## Routes

- `POST /feedback`: public demo submission route with server-side validation.
- `GET /admin/feedback`: requires the `x-admin-token` header.

## Important security and academic limitations

- The admin token in this simple demo is not a production identity system. Anyone who can access browser developer tools may inspect requests, and a shared token can be misused. Use Amazon Cognito or institutional authentication and enforce authorization in Lambda before real deployment.
- This demo stores student identifiers and comments. Use dummy data during development and follow your institution's privacy requirements.
- `ALLOWED_ORIGIN=*` is for initial testing only, not a production recommendation.
- The admin dashboard uses a DynamoDB Scan and is intended for small demo datasets, not high-scale production.
- Add pagination, rate limiting, spam prevention, retention rules, and authentication before real use.
- AWS Academy Learner Lab service availability and permissions vary. The app code is a starter; successful deployment depends on your lab's allowed services and IAM permissions.
